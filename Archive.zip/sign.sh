#!/bin/sh

echo 'Welcome to zsign iOS app signer By xZEKOxX'
for i in sign/*.ipa ; do
chmod +x .
zsign -k "u.p12" -m "u.mobileprovision" -p "hell23" -z 9 -o /var/mobile/Containers/Data/Application/EF0EE74D-59AD-4CE6-BA51-146FAFCBC08E/Documents/$i "$i" 
done
exit